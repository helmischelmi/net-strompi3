﻿using System;
using System.Threading.Tasks;
using Pi.Common;
using Pi.Common.io.email;
using Strompi3Lib.serialPort;


namespace Strompi3Lib;


public class UpsMonitor
{
    private readonly ShutdownCoordinator _shutdownCoordinator;


    private const string PowerFailureMessage = "StromPiPowerfail";
    private const string ShutDownMessage = "ShutdownRaspberryPi";
    private const string PowerBackMessage = "StromPiPowerBack";

    private StromPi3 _strompi3;
    private EUpsState State;
    private DateTime PowerFailureStart;


    public UpsMonitor(StromPi3 strompi3)
    {
        _strompi3 = strompi3;
        _shutdownCoordinator = _strompi3.ShutdownCoordinator;
        
        State = EUpsState.PowerOk;
        _strompi3.PortManager.PowerChangeDetected += OnPowerChanged;
        Console.WriteLine("OnPowerChanged registriert");
    }


    public void DeRegisterPowerChange()
    {
        _strompi3.PortManager.PowerChangeDetected -= OnPowerChanged;
        Console.WriteLine("OnPowerChanged deregistriert");
    }


    /// <summary>
    /// event handler, registered to the powerChangeDetected event of StromPi3.
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnPowerChanged(object sender, EventArgs e)
    {
        var msg = ((SerialPortEventArgs)e).Message;
        Console.WriteLine("\nOnPowerChanged Eventhandler ausgelöst in UPSMonitor\n");

        if (msg.Contains(PowerFailureMessage)) HandlePowerFailure();
        else if (msg.Contains(ShutDownMessage)) HandleShutDown();
        else if (msg.Contains(PowerBackMessage)) HandlePowerBack();

    }

    private void HandlePowerFailure()
    {
        Console.WriteLine(" - OnPowerFailure erkannt");
        SetState(EUpsState.PowerIsMissing);
        PerformCountdownToShutdown();
    }

    private void HandleShutDown()
    {
        Console.WriteLine(" - OnShutDown erkannt");
        
        SetState(EUpsState.ShutdownNow);
        PerformShutdown();
    }

    private void HandlePowerBack()
    {
        SetState(EUpsState.PowerBack);
        Console.WriteLine(" - OnPowerBack erkannt");
    }


    /// <summary>
    /// 
    /// </summary>
    /// <param name="state"></param>
    public void SetState(EUpsState state)
    {
        State = state;
        Console.WriteLine($"State changed to {State}");
    }


    private void PerformCountdownToShutdown()
    {
        Console.WriteLine($"STATE Power is Missing");
        Console.WriteLine($"Countdown is enabled  : {_strompi3.Cfg.ShutdownEnable}");
        Console.WriteLine($"Failure counter is    : {_strompi3.Cfg.PowerFailureCounter}");
        Console.WriteLine($"Countdown to shutdown : {_strompi3.Cfg.ShutdownSeconds} seconds");

        SmtpMailer.SendEmail(SmtpConfiguration.GetDefaultConfiguration(), "LurchiCam PowerFailure", $"Got PowerFailure-Signal from StromPi3 and start countdown to shutdown at {DateTime.Now.ToLongTimeString()}!");


        PowerFailureStart = DateTime.Now;
        int secondsToShutdown = _strompi3.Cfg.ShutdownSeconds;

        while ((DateTime.Now - PowerFailureStart).TotalSeconds < secondsToShutdown && State == EUpsState.PowerIsMissing)
        {
            int elapsed = (int)(DateTime.Now - PowerFailureStart).TotalSeconds;
            Console.Write($"\rCountdown {elapsed} of {secondsToShutdown} seconds");
            Task.Delay(900).Wait();
        }
        Console.WriteLine();

        if (State == EUpsState.PowerIsMissing)
        {
            Console.WriteLine("Countdown finished – Shutdown will be initiated.");
            _ = _shutdownCoordinator.OnShutdownRequestedAsync();
            PerformShutdown();// Countdown abgelaufen, Shutdown starten
        }
        else
        {
            Console.WriteLine("Countdown interrupted due to power recovery.");
        }
    }

    private void PerformShutdown()
    {
        SetState(EUpsState.ShutdownNow);

        _strompi3.ReceiveStatus();  // die serielle Verbindung ist bei Shutdown nicht mehr verfügbar
                                    // daher wird das hier nix. 
        Console.WriteLine($"Countdown is enabled  : {_strompi3.Cfg.ShutdownEnable}");
        Console.WriteLine($"Failure counter is    : {_strompi3.Cfg.PowerFailureCounter}");
        Console.WriteLine($"Countdown to shutdown : {_strompi3.Cfg.ShutdownSeconds} seconds");
        Console.WriteLine($"Battery Level : {_strompi3.Cfg.BatteryHat.Level} ");

        Console.WriteLine($"SET Shutdown at {DateTime.Now.ToLongTimeString()}");

        SmtpMailer.SendEmail(SmtpConfiguration.GetDefaultConfiguration(), "LurchiCam shuts down", $"Got ShutDown-Signal from StromPi3 at {DateTime.Now.ToLongTimeString()}!");
        
        Console.WriteLine(" Shutdown wird eingeleitet.");
        // Shutdown SEQUENZ starten (asynchron!)
        _ = _shutdownCoordinator.OnShutdownRequestedAsync();

        //Task.Delay(2000).Wait();
        //Os.ShutDown();
    }


}
